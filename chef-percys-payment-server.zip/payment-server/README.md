# Chèf Percy's Kitchen — payment server

Takes real payments from **Airtel Money, MTN MoMo and Zamtel Kwacha** through
[Lenco](https://lenco.co/zm), a Zambian payment provider. One integration
covers all three networks.

The customer enters their number on the website, gets a prompt on their phone,
approves it with their PIN, and the order is marked paid with a receipt —
no transaction IDs to copy.

## How it fits together

```
Website ──POST /payments/mobile-money──▶ This server ──▶ Lenco ──▶ customer's phone
Website ◀──GET /payments/status/{ref}─── This server ◀── Lenco webhook (signed)
```

The Lenco secret token lives only on this server. The website never sees it.

## What Percy needs first (the slow part)

1. **A Lenco business account** at https://lenco.co/zm. Expect them to ask for
   PACRA registration, TPIN and ID. Lenco is reachable on +260 975 687 373.
2. **API access enabled** on that account, then copy the **API token**.
3. **Webhook URL** set in the Lenco dashboard (Lenco Pay section) to
   `https://<this-server>/webhooks/lenco`.

Until step 1 is done, nothing can go live. Everything else below takes an hour.

## Run locally

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows PowerShell
# source .venv/bin/activate     # macOS / Linux
pip install -r requirements.txt
copy .env.example .env          # then fill in LENCO_API_TOKEN
uvicorn main:app --reload
```

Open http://127.0.0.1:8000/docs to try every endpoint.

Run the tests (no Lenco account needed — the provider is mocked):

```bash
pip install pytest
pytest -q
```

## Deploy on Render

1. Push this folder to a GitHub repo.
2. In Render: **New → Blueprint**, pick the repo. `render.yaml` creates the web
   service and a Postgres database.
3. Set `LENCO_API_TOKEN` and `ALLOWED_ORIGINS` (the website address) in the
   service's Environment tab.
4. Check `https://<service>.onrender.com/health` returns `"configured": true`.
5. Put the webhook URL into the Lenco dashboard.

Use a paid Render instance in production. Free instances sleep, and a sleeping
server misses webhooks (the status polling recovers them, but slowly).

## Connect the website

In the website dashboard → **Payment setup**:

1. Switch **Online payments** to **Live**.
2. Paste the server address, e.g. `https://chef-percys-payments.onrender.com`.
3. Press **Test connection**.

The website must be hosted on its own domain for this to work (claude.ai
previews block outside network calls, so the preview always runs in demo mode).

## Endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/health` | Is the server up and is Lenco configured? |
| POST | `/payments/mobile-money` | Send a payment prompt to a phone |
| GET | `/payments/status/{reference}` | Current status; re-queries Lenco if still waiting |
| GET | `/payments/order/{order_ref}` | Every attempt for one order |
| POST | `/webhooks/lenco` | Lenco's signed notifications |

## Safety built in

- **Webhook signatures verified** (HMAC-SHA512 keyed by SHA-256 of the API token, per Lenco's docs). Forged "paid" messages are rejected.
- **No double charging** — the same reference never sends a second prompt.
- **Network check** — a 096 number cannot be charged as Airtel.
- **Prompt-spam limit** — 6 payment starts per minute per visitor (configurable).
- **Amount limits** — K1 to K20,000 per payment (configurable).
- **Missed webhooks recovered** — status checks re-query Lenco directly.
- **Paid stays paid** — a late or out-of-order notification cannot undo a successful payment.

## One thing to finish before heavy use

Right now the **website tells this server the amount**. A determined customer
could tamper with that and pay less than the order total. Percy would see the
mismatch (the dashboard shows what was received), but the proper fix is to move
orders and menu prices onto this server so it calculates the total itself.
That is the next piece of work once the business is live.

## Bank transfers and cash

Lenco's collection API covers mobile money and cards, not pulling money from a
bank account. Bank transfers stay as they are on the website: the customer
transfers using the order reference and enters the transaction ID, and Percy
confirms it. Cash on collection is unchanged.
