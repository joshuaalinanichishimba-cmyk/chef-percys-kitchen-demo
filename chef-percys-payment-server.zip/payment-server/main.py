"""
Chèf Percy's Kitchen — payment server
=====================================

Collects mobile-money payments from Airtel Money, MTN MoMo and Zamtel Kwacha
through Lenco (https://lenco.co/zm). The website never sees the Lenco API
token: it asks this server to start a payment, then polls this server for the
result. Lenco confirms each payment to this server by signed webhook.

Flow
----
1. Website  -> POST /payments/mobile-money   (reference, amount, phone, operator)
2. Server   -> Lenco POST /collections/mobile-money
3. Customer approves the prompt on their phone with their PIN
4. Lenco    -> POST /webhooks/lenco           (signed: X-Lenco-Signature)
5. Website  -> GET  /payments/status/{reference}   (polls every few seconds)

If a webhook is missed, /payments/status re-queries Lenco directly, so a
payment is never stuck because one notification failed to arrive.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import re
import threading
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Literal, Optional

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import DateTime, Numeric, String, Text, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column

# --------------------------------------------------------------------------
# Configuration (all from environment variables — see .env.example)
# --------------------------------------------------------------------------
LENCO_API_TOKEN = os.getenv("LENCO_API_TOKEN", "")
LENCO_BASE_URL = os.getenv("LENCO_BASE_URL", "https://api.lenco.co/access/v2").rstrip("/")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./payments.db")
ALLOWED_ORIGINS = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "").split(",") if o.strip()]
FEE_BEARER = os.getenv("FEE_BEARER", "merchant")            # "merchant" or "customer"
MIN_AMOUNT = Decimal(os.getenv("MIN_AMOUNT", "1"))
MAX_AMOUNT = Decimal(os.getenv("MAX_AMOUNT", "20000"))      # sanity cap per payment, in Kwacha
REQUERY_AFTER_SECONDS = int(os.getenv("REQUERY_AFTER_SECONDS", "5"))
RATE_LIMIT_PER_MINUTE = int(os.getenv("RATE_LIMIT_PER_MINUTE", "6"))

# Render and Heroku hand out postgres:// URLs; SQLAlchemy 2 needs postgresql://
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = "postgresql://" + DATABASE_URL[len("postgres://"):]

log = logging.getLogger("payments")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

OPERATORS = {"airtel": "Airtel Money", "mtn": "MTN MoMo", "zamtel": "Zamtel Kwacha"}
# Zambian mobile prefixes: 097/077 Airtel, 096/076 MTN, 095/075 Zamtel
PREFIX_TO_OPERATOR = {"7": "airtel", "6": "mtn", "5": "zamtel"}
REFERENCE_RE = re.compile(r"^[A-Za-z0-9._-]{3,60}$")


# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
class Base(DeclarativeBase):
    pass


class Payment(Base):
    __tablename__ = "payments"

    reference: Mapped[str] = mapped_column(String(64), primary_key=True)
    order_ref: Mapped[str] = mapped_column(String(64), index=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    amount_received: Mapped[Optional[Decimal]] = mapped_column(Numeric(12, 2), nullable=True)
    phone: Mapped[str] = mapped_column(String(16))
    operator: Mapped[str] = mapped_column(String(10))
    customer_name: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending | successful | failed
    lenco_status: Mapped[Optional[str]] = mapped_column(String(16), nullable=True)
    lenco_reference: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    operator_txn_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    reason: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    raw: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
    pool_pre_ping=True,
)
Base.metadata.create_all(engine)


def now() -> datetime:
    return datetime.now(timezone.utc)


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def normalise_phone(raw: str) -> Optional[str]:
    """Return a Zambian mobile number as 0XXXXXXXXX, or None if it is not one."""
    digits = re.sub(r"\D", "", raw or "")
    if digits.startswith("260"):
        digits = digits[3:]
    if len(digits) == 9:
        digits = "0" + digits
    return digits if re.fullmatch(r"0[79][5-7]\d{7}", digits) else None


def operator_for(phone: str) -> Optional[str]:
    return PREFIX_TO_OPERATOR.get(phone[2]) if phone else None


def map_status(lenco_status: Optional[str]) -> str:
    if lenco_status == "successful":
        return "successful"
    if lenco_status == "failed":
        return "failed"
    return "pending"  # "pending" and "pay-offline" both mean: waiting for the customer


def to_out(p: Payment) -> dict:
    return {
        "reference": p.reference,
        "order_ref": p.order_ref,
        "status": p.status,
        "amount": str(p.amount),
        "amount_received": str(p.amount_received) if p.amount_received is not None else None,
        "operator": p.operator,
        "operator_label": OPERATORS.get(p.operator, p.operator),
        "phone": p.phone,
        "operator_transaction_id": p.operator_txn_id,
        "lenco_reference": p.lenco_reference,
        "reason": p.reason,
        "updated_at": p.updated_at.isoformat() if p.updated_at else None,
    }


def apply_lenco(p: Payment, data: dict) -> None:
    """Copy a Lenco collection object onto our payment record."""
    lenco_status = data.get("status")
    p.lenco_status = lenco_status
    # A finished payment never moves back to pending (webhooks can arrive out of order)
    if p.status in ("successful", "failed") and map_status(lenco_status) == "pending":
        return
    p.status = map_status(lenco_status)
    p.lenco_reference = data.get("lencoReference") or p.lenco_reference
    p.reason = data.get("reasonForFailure") or (None if p.status != "failed" else p.reason)
    mm = data.get("mobileMoneyDetails") or {}
    p.operator_txn_id = mm.get("operatorTransactionId") or p.operator_txn_id
    try:
        if data.get("amount") is not None:
            p.amount_received = Decimal(str(data["amount"]))
    except InvalidOperation:
        pass
    p.raw = json.dumps(data)[:8000]
    p.updated_at = now()


# Lenco HTTP client — a function so tests can swap in a fake transport
_client: Optional[httpx.Client] = None


def lenco() -> httpx.Client:
    global _client
    if _client is None:
        _client = httpx.Client(
            base_url=LENCO_BASE_URL,
            headers={"Authorization": f"Bearer {LENCO_API_TOKEN}", "Content-Type": "application/json"},
            timeout=httpx.Timeout(30.0, connect=10.0),
        )
    return _client


def set_lenco_client(client: httpx.Client) -> None:
    global _client
    _client = client


# Simple per-IP rate limit on starting payments, so nobody can spam
# payment prompts to random phone numbers.
_hits: dict[str, deque] = defaultdict(deque)
_hits_lock = threading.Lock()


def rate_limited(ip: str) -> bool:
    cutoff = time.time() - 60
    with _hits_lock:
        q = _hits[ip]
        while q and q[0] < cutoff:
            q.popleft()
        if len(q) >= RATE_LIMIT_PER_MINUTE:
            return True
        q.append(time.time())
        return False


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------
app = FastAPI(title="Chèf Percy's Kitchen — payments", version="1.0.0")

if ALLOWED_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=ALLOWED_ORIGINS,
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
    )


class MobileMoneyIn(BaseModel):
    reference: str = Field(..., description="Unique per payment attempt, e.g. CPK-1007 or CPK-1007-2")
    order_ref: str
    amount: Decimal
    phone: str
    operator: Literal["airtel", "mtn", "zamtel"]
    customer_name: Optional[str] = Field(default=None, max_length=120)

    @field_validator("reference", "order_ref")
    @classmethod
    def _ref(cls, v: str) -> str:
        if not REFERENCE_RE.fullmatch(v):
            raise ValueError("Only letters, numbers, '-', '.' and '_' are allowed (3–60 characters).")
        return v

    @field_validator("amount")
    @classmethod
    def _amount(cls, v: Decimal) -> Decimal:
        v = v.quantize(Decimal("0.01"))
        if v < MIN_AMOUNT or v > MAX_AMOUNT:
            raise ValueError(f"Amount must be between K{MIN_AMOUNT} and K{MAX_AMOUNT}.")
        return v


@app.get("/health")
def health():
    return {"ok": True, "configured": bool(LENCO_API_TOKEN), "operators": list(OPERATORS)}


@app.post("/payments/mobile-money")
def start_mobile_money(body: MobileMoneyIn, request: Request):
    if not LENCO_API_TOKEN:
        raise HTTPException(503, "The payment server has no Lenco API token configured.")

    phone = normalise_phone(body.phone)
    if not phone:
        raise HTTPException(400, "Enter a Zambian mobile money number, for example 0971234567.")
    detected = operator_for(phone)
    if detected != body.operator:
        raise HTTPException(
            400, f"{phone} is a {OPERATORS.get(detected, 'different')} number, not {OPERATORS[body.operator]}."
        )

    with Session(engine) as db:
        existing = db.get(Payment, body.reference)
        if existing:
            # Idempotent: a retry of the SAME payment returns its status without a second prompt.
            # A DIFFERENT payment reusing the reference is refused, so one customer's
            # success can never be credited to another order.
            if (existing.order_ref, existing.amount, existing.phone) != (body.order_ref, body.amount, phone):
                raise HTTPException(409, "That payment reference has already been used for a different payment.")
            return to_out(existing)

    if rate_limited(request.client.host if request.client else "unknown"):
        raise HTTPException(429, "Too many payment requests. Wait a minute and try again.")

    payload = {
        "amount": float(body.amount),
        "reference": body.reference,
        "phone": phone,
        "operator": body.operator,
        "country": "zm",
        "bearer": FEE_BEARER,
    }
    t = now()
    p = Payment(
        reference=body.reference, order_ref=body.order_ref, amount=body.amount, phone=phone,
        operator=body.operator, customer_name=body.customer_name, status="pending",
        created_at=t, updated_at=t,
    )

    try:
        r = lenco().post("/collections/mobile-money", json=payload)
        res = r.json()
    except (httpx.HTTPError, ValueError) as e:
        log.exception("Lenco request failed for %s", body.reference)
        raise HTTPException(502, "The payment provider did not respond. Try again in a moment.") from e

    if r.status_code >= 400 or not res.get("status"):
        p.status = "failed"
        p.reason = (res.get("message") or "The payment provider rejected the request.")[:255]
        p.raw = json.dumps(res)[:8000]
        with Session(engine) as db:
            db.add(p)
            db.commit()
            db.refresh(p)
            log.info("Payment %s rejected: %s", p.reference, p.reason)
            return to_out(p)

    apply_lenco(p, res.get("data") or {})
    with Session(engine) as db:
        db.add(p)
        db.commit()
        db.refresh(p)
        log.info("Payment %s started: %s %s K%s -> %s", p.reference, p.operator, p.phone, p.amount, p.status)
        return to_out(p)


@app.get("/payments/status/{reference}")
def payment_status(reference: str):
    if not REFERENCE_RE.fullmatch(reference):
        raise HTTPException(400, "Invalid reference.")
    with Session(engine) as db:
        p = db.get(Payment, reference)
        if not p:
            raise HTTPException(404, "No payment with that reference.")

        stale = (now() - p.updated_at.replace(tzinfo=p.updated_at.tzinfo or timezone.utc)).total_seconds()
        if p.status == "pending" and stale >= REQUERY_AFTER_SECONDS and LENCO_API_TOKEN:
            try:
                r = lenco().get(f"/collections/status/{reference}")
                res = r.json()
                if r.status_code < 400 and res.get("status") and res.get("data"):
                    apply_lenco(p, res["data"])
                else:
                    p.updated_at = now()
                db.commit()
                db.refresh(p)
            except (httpx.HTTPError, ValueError):
                log.warning("Re-query failed for %s; will try again on next poll", reference)
        return to_out(p)


@app.get("/payments/order/{order_ref}")
def payments_for_order(order_ref: str):
    if not REFERENCE_RE.fullmatch(order_ref):
        raise HTTPException(400, "Invalid order reference.")
    with Session(engine) as db:
        rows = db.scalars(select(Payment).where(Payment.order_ref == order_ref).order_by(Payment.created_at)).all()
        return [to_out(p) for p in rows]


def webhook_key() -> bytes:
    """Lenco signs webhooks with HMAC-SHA512 keyed by the hex SHA-256 of the API token."""
    return hashlib.sha256(LENCO_API_TOKEN.encode()).hexdigest().encode()


@app.post("/webhooks/lenco")
async def lenco_webhook(request: Request):
    raw = await request.body()
    sent = request.headers.get("x-lenco-signature", "")
    expected = hmac.new(webhook_key(), raw, hashlib.sha512).hexdigest()
    if not LENCO_API_TOKEN or not hmac.compare_digest(sent, expected):
        log.warning("Rejected webhook with bad signature")
        raise HTTPException(401, "Invalid signature.")

    try:
        event = json.loads(raw)
    except ValueError:
        return {"ok": True}  # acknowledge so Lenco stops retrying a malformed body

    kind = event.get("event", "")
    data = event.get("data") or {}
    ref = data.get("reference")
    if kind.startswith("collection.") and ref:
        with Session(engine) as db:
            p = db.get(Payment, ref)
            if p:
                apply_lenco(p, data)
                db.commit()
                log.info("Webhook %s for %s -> %s", kind, ref, p.status)
            else:
                log.info("Webhook %s for unknown reference %s", kind, ref)
    return {"ok": True}
