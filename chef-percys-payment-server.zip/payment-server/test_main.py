"""Run with:  pytest -q"""
import hashlib
import hmac
import json
import os
import tempfile

os.environ["LENCO_API_TOKEN"] = "test-token-123"
os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(tempfile.mkdtemp(), "t.db")
os.environ["REQUERY_AFTER_SECONDS"] = "0"
os.environ["RATE_LIMIT_PER_MINUTE"] = "100"

import httpx  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

import main  # noqa: E402

CALLS = []
STATE = {"status": "pay-offline"}


def fake_lenco(request: httpx.Request) -> httpx.Response:
    CALLS.append((request.method, request.url.path, json.loads(request.content or b"{}")))
    if request.url.path.endswith("/collections/mobile-money"):
        body = json.loads(request.content)
        if body["phone"] == "0970000000":
            return httpx.Response(400, json={"status": False, "message": "Insufficient balance"})
        return httpx.Response(200, json={"status": True, "message": "", "data": {
            "id": "c1", "amount": str(body["amount"]), "currency": "ZMW", "reference": body["reference"],
            "lencoReference": "L-1", "type": "mobile-money", "status": "pay-offline",
            "reasonForFailure": None, "mobileMoneyDetails": {"phone": body["phone"], "operator": body["operator"],
                                                             "operatorTransactionId": None}}})
    if "/collections/status/" in request.url.path:
        ref = request.url.path.rsplit("/", 1)[1]
        return httpx.Response(200, json={"status": True, "data": {
            "reference": ref, "status": STATE["status"], "lencoReference": "L-1", "amount": "120.00",
            "reasonForFailure": None,
            "mobileMoneyDetails": {"operatorTransactionId": "MP261116.1200.A00042"}}})
    return httpx.Response(404, json={"status": False})


main.set_lenco_client(httpx.Client(base_url="https://api.lenco.co/access/v2", transport=httpx.MockTransport(fake_lenco)))
client = TestClient(main.app)


def sign(body: bytes) -> str:
    key = hashlib.sha256(b"test-token-123").hexdigest().encode()
    return hmac.new(key, body, hashlib.sha512).hexdigest()


def start(ref, phone="0977123456", op="airtel", amount=120):
    return client.post("/payments/mobile-money", json={
        "reference": ref, "order_ref": ref.split("-A")[0], "amount": amount, "phone": phone, "operator": op})


def test_health():
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["configured"] is True


def test_phone_normalisation():
    assert main.normalise_phone("+260 97 712 3456") == "0977123456"
    assert main.normalise_phone("977123456") == "0977123456"
    assert main.normalise_phone("0760892063") == "0760892063"
    assert main.normalise_phone("0211234567") is None  # landline
    assert main.operator_for("0779079908") == "airtel"
    assert main.operator_for("0960000000") == "mtn"
    assert main.operator_for("0955000000") == "zamtel"


def test_start_sends_correct_payload_and_waits():
    r = start("CPK-1001")
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["status"] == "pending" and j["operator_label"] == "Airtel Money"
    method, path, body = CALLS[-1]
    assert path.endswith("/collections/mobile-money")
    assert body == {"amount": 120.0, "reference": "CPK-1001", "phone": "0977123456",
                    "operator": "airtel", "country": "zm", "bearer": "merchant"}


def test_wrong_network_is_rejected():
    r = start("CPK-1002", phone="0961234567", op="airtel")
    assert r.status_code == 400 and "MTN" in r.json()["detail"]


def test_same_reference_never_prompts_twice():
    n = len(CALLS)
    start("CPK-1003")
    start("CPK-1003")
    assert len([c for c in CALLS[n:] if c[1].endswith("/collections/mobile-money")]) == 1


def test_provider_rejection_is_reported():
    r = start("CPK-1004", phone="0970000000")
    assert r.status_code == 200 and r.json()["status"] == "failed"
    assert "Insufficient" in r.json()["reason"]


def test_amount_limits():
    assert start("CPK-1005", amount=0).status_code == 422
    assert start("CPK-1006", amount=999999).status_code == 422


def test_polling_picks_up_success_without_webhook():
    start("CPK-1007")
    STATE["status"] = "successful"
    j = client.get("/payments/status/CPK-1007").json()
    STATE["status"] = "pay-offline"
    assert j["status"] == "successful"
    assert j["operator_transaction_id"] == "MP261116.1200.A00042"


def test_webhook_rejects_bad_signature():
    body = json.dumps({"event": "collection.successful", "data": {"reference": "CPK-1001", "status": "successful"}}).encode()
    r = client.post("/webhooks/lenco", content=body, headers={"X-Lenco-Signature": "nope"})
    assert r.status_code == 401
    assert client.get("/payments/order/CPK-1001").json()[0]["status"] == "pending"


def test_webhook_with_valid_signature_marks_paid_and_cannot_be_undone():
    body = json.dumps({"event": "collection.successful", "data": {
        "reference": "CPK-1001", "status": "successful", "amount": "120.00", "lencoReference": "L-9",
        "mobileMoneyDetails": {"operatorTransactionId": "MP261116.0900.B77"}}}).encode()
    r = client.post("/webhooks/lenco", content=body, headers={"X-Lenco-Signature": sign(body)})
    assert r.status_code == 200
    late = json.dumps({"event": "collection.failed", "data": {"reference": "CPK-1001", "status": "pay-offline"}}).encode()
    client.post("/webhooks/lenco", content=late, headers={"X-Lenco-Signature": sign(late)})
    j = client.get("/payments/order/CPK-1001").json()[0]
    assert j["status"] == "successful" and j["operator_transaction_id"] == "MP261116.0900.B77"


def test_reused_reference_for_a_different_payment_is_refused():
    start("CPK-2001")
    r = client.post("/payments/mobile-money", json={
        "reference": "CPK-2001", "order_ref": "CPK-2001", "amount": 120, "phone": "0977999888", "operator": "airtel"})
    assert r.status_code == 409
    r = client.post("/payments/mobile-money", json={
        "reference": "CPK-2001", "order_ref": "CPK-2001", "amount": 50, "phone": "0977123456", "operator": "airtel"})
    assert r.status_code == 409
